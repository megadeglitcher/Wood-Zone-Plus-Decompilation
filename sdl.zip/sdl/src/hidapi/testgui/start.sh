#!/bin/bash
xterm -e /Users/alan/work/hidapi/testgui/TestGUI.app/Contents/MacOS/tg
