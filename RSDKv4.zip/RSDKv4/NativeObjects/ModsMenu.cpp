#include "RetroEngine.hpp"

#if RETRO_USE_MOD_LOADER
void ModsMenu_Create(void *objPtr) { RSDK_THIS(ModsMenu); }
void ModsMenu_Main(void *objPtr) { RSDK_THIS(ModsMenu); }
#endif