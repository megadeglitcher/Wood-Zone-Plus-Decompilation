#include "RetroEngine.hpp"

#if RETRO_USE_MOD_LOADER
void ModInfoButton_Create(void *objPtr) { RSDK_THIS(ModInfoButton); }
void ModInfoButton_Main(void *objPtr) { RSDK_THIS(ModInfoButton); }
#endif
